
dd of=$ORACLE_BASE/oradata/orcl/example01.dbf bs=8192 conv=notrunc seek=36 << EOF
CORRUPT corrupt CORRUPT corrupt CORRUPT corrupt CORRUPT corrupt CORRUPT corrupt  
EOF                                                                              
                                                                                 
