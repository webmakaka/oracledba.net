echo "******************************************* "
echo "For demo purposes ONLY"
echo "Create data corruption for scenario 1"

./dra_shutdown.sh 

./dra1_corruption.sh  

echo "Setup 1 completed."
exit