drop directory imagedir;


