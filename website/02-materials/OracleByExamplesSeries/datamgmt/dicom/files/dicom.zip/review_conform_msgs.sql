describe orddcm_conformance_vld_msgs;
select * from orddcm_conformance_vld_msgs;


