drop procedure image_import;
drop procedure generate_thumb;
drop procedure generate_anon;
drop procedure dicom_export;
drop table     medical_image_table;


