col id     format a5
col sop_instance_uid  format a60
col sop_class_uid  format a27
col study_instance_uid format a60
col series_instance_uid format a60
col patient_name format a25
col patient_id format a25
col modality format a25
set lines 120 
set pages 1000
set echo on 