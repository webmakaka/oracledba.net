connect sf_demo/oracle

set serveroutput on
set pause off
set echo on

exec check_space_&Enter_BF_or_SF_for_LOB_type

