connect sh/sh
drop table sales_nocompress purge
/
drop table sales_compress_direct purge
/
drop table sales_compress_oltp purge
/
