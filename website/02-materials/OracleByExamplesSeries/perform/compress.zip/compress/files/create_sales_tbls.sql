set echo off
REM RUDIMENTARY COMPRESSION OBE
REM
REM v0.1
REM
REM jwomack     05/16/07        - initial creation
REM pavril	05/31/07	- added oltp table
REM
REM
REM Create compressed and uncompressed versions of the SALES table
set echo off
set pagesize 2000
set long 10000
set linesize 200
REM
REM
connect sh/sh
drop table sales_nocompress purge
/
drop table sales_compress_direct purge
/
drop table sales_compress_oltp purge
/
set echo on
set timing on
create table sales_nocompress
as select * from sales
/

create table sales_compress_direct compress
as select * from sales
/
create table sales_compress_oltp compress
as select * from sales
where 1=0
/

set timing off
