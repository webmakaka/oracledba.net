select count(*)
from customers_obe
where country_id = 'US' and cust_state_province = 'CA';