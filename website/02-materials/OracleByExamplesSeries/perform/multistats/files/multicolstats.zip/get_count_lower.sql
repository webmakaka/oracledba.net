select count(*)
from customers_obe
where lower(country_id) = 'us';