   INSERT INTO dependents VALUES ( 210, 'David', 'Griffiths',
     TO_DATE('2-APR-99', 'dd-MON-rr'), 'son', 201);

   INSERT INTO dependents VALUES ( 212, 'Jill', 'Reed', 
     TO_DATE('10-FEB-92', 'dd-MON-rr'), 'daughter', 110);

   INSERT INTO dependents VALUES ( 214, 'Vicki', 'Dean',
     TO_DATE('19-AUG-01', 'dd-MON-rr'), 'daughter', 201);
        
   INSERT INTO dependents VALUES ( 215, 'Don', 'King',
      TO_DATE('24-OCT-89', 'dd-MON-rr'), 'son', 120);
        
       
        
        