ALTER TABLE sales_delta_xt location ( 'salesQ1.dat' );
