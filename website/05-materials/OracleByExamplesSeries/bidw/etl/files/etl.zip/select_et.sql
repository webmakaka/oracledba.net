Rem   *****
PROMPT   what's in the ET
Rem   serial
Rem   *****

SELECT COUNT(*) FROM sales_delta_xt;
SELECT MAX(time_id) FROM sales_delta_xt;
