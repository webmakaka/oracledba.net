SELECT COUNT(*) 
FROM sales PARTITION (sales_q1_2002);

SELECT COUNT(*)
FROM sales_delta;