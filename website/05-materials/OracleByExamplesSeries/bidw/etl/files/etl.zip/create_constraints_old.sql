Rem   ***10g***
REM   TO DO: cannot enable fk rely when pk is set to norely
Rem   *****

ALTER TABLE channels MODIFY CONSTRAINT CHANNELS_PK RELY;
ALTER TABLE countries MODIFY CONSTRAINT COUNTRIES_PK RELY;
ALTER TABLE customers MODIFY CONSTRAINT CUSTOMERS_PK RELY;
ALTER TABLE products MODIFY CONSTRAINT PRODUCTS_PK RELY;
ALTER TABLE promotions MODIFY CONSTRAINT PROMO_PK RELY;
ALTER TABLE times MODIFY CONSTRAINT TIMES_PK RELY;

ALTER TABLE sales_old_q1_1998
ADD ( CONSTRAINT sales_product_old_fk
      FOREIGN KEY (prod_id)
      REFERENCES products RELY ENABLE NOVALIDATE
    , CONSTRAINT sales_customer_old_fk
      FOREIGN KEY (cust_id)
      REFERENCES customers RELY ENABLE NOVALIDATE
    , CONSTRAINT sales_time_old_fk
      FOREIGN KEY (time_id)
      REFERENCES times RELY ENABLE NOVALIDATE
    , CONSTRAINT sales_channel_old_fk
      FOREIGN KEY (channel_id)
      REFERENCES channels RELY ENABLE NOVALIDATE
    , CONSTRAINT sales_promo_old_fk
      FOREIGN KEY (promo_id)
      REFERENCES promotions RELY ENABLE NOVALIDATE
    ) ;