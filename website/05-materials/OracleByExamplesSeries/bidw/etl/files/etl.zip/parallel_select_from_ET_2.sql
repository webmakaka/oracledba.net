SELECT /*+ parallel(a,4) */ count(*) 
FROM sales_delta_XT a;

rem ALTER TABLE sales_delta_XT PARALLEL 4;
