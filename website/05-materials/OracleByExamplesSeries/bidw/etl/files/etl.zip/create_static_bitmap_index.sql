CREATE BITMAP INDEX sales_prod_local_bix
       ON sales_delta (prod_id)
       NOLOGGING COMPUTE STATISTICS ;
CREATE BITMAP INDEX sales_cust_local_bix
       ON sales_delta (cust_id)
       NOLOGGING COMPUTE STATISTICS ;
CREATE BITMAP INDEX sales_time_local_bix
       ON sales_delta (time_id)
       NOLOGGING COMPUTE STATISTICS ;
CREATE BITMAP INDEX sales_channel_local_bix
       ON sales_delta (channel_id)
       NOLOGGING COMPUTE STATISTICS ;
CREATE BITMAP INDEX sales_promo_local_bix
       ON sales_delta (promo_id)
       NOLOGGING COMPUTE STATISTICS ;
