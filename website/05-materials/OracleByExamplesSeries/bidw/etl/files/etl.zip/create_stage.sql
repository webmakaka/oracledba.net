CREATE TABLE sales_dec01 AS
  SELECT * 
  FROM   sales 
  WHERE  1=0;

ALTER TABLE sales_dec01 MODIFY (channel_id CHAR(2) null); 
