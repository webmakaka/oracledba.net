rem Now run it over and over by using SQL*Plus rerun functionality
rem issuing r on the SQL> prompt.

SELECT /*+ INDEX(sales, sales_pk) */ count(*)
FROM   sales
WHERE  prod_id BETWEEN 100 AND 500;