exec dbms_stats.delete_table_stats('SH', 'CUSTOMERS_OBE');

