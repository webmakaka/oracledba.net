execute dbms_stats.gather_table_stats('SH', 'CUSTOMERS_OBE');
