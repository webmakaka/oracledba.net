alter session set optimizer_use_pending_statistics = false;
alter session set optimizer_dynamic_sampling = 0;