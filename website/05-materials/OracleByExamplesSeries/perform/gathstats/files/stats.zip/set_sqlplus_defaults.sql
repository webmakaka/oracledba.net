col publish     format a18
col table_name  format a18
col index_name  format a21
col column_name format a22
col stale_percent format a20
set lines 120 
set pages 1000
set echo on 