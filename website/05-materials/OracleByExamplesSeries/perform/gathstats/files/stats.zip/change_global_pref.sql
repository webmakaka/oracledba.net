connect / as sysdba
execute dbms_stats.set_global_prefs('STALE_PERCENT', '13');


