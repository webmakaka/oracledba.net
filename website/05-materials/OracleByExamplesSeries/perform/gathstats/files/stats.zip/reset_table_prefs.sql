execute dbms_stats.delete_table_prefs('SH', 'SALES', 'STALE_PERCENT');
