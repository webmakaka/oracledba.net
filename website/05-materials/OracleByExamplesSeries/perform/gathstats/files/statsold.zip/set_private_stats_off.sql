alter session set optimizer_private_statistics = false;
alter session set optimizer_dynamic_sampling = 0;