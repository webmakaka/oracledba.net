execute dbms_stats.set_table_prefs('SH', 'SALES', 'STALE_PERCENT', '65');

