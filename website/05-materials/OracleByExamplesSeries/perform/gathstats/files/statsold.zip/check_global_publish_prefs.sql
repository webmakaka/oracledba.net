select dbms_stats.get_prefs('PUBLISH') publish from dual;
