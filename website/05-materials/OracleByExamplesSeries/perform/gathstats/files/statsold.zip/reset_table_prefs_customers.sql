exec dbms_stats.delete_table_prefs('SH', 'CUSTOMERS', 'PUBLISH');

