connect sh/sh
drop table sales_nocompress purge
/
drop table sales_compress purge
/
drop table q_sales purge;
drop table q_sales2 purge;

