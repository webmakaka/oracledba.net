export ORACLE_HOME=/app/ora11/app/ora11/product/11.1.0/db_1 
export PATH=$PATH:/app/ora11/app/ora11/product/11.1.0/db_1/bin
export DEMO_HOME=/scratch/ora11/sqlreplay/sql_replay_100q
export ORACLE_SID=orcl
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib
#/app/ora11/app/ora11/product/11.1.0/db_1/lib

