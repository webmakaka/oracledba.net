export ORACLE_HOME=/app/oracle/product/11g
export PATH=$PATH:/app/oracle/product/11g/bin
export DEMO_HOME=/scratch/ora11/sqlreplay/sql_replay_100q
export ORACLE_SID=orcl
