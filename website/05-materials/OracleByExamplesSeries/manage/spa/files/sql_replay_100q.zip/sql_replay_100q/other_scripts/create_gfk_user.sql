create user gfk identified by gfk; 
grant dba to gfk; 
grant execute on dbms_sqltune_internal to gfk; 
