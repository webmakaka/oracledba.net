create user apps identified by apps; 
grant dba to apps; 
grant execute on dbms_sqltune_internal to apps; 
grant create any sql profile to apps;
grant select on scott.lu_pg_featurevalue_15 to apps; 
grant select on scott.lu_elementrange_rel to apps; 
