csh -c 'pkill -9 ^wcr_demo$'
