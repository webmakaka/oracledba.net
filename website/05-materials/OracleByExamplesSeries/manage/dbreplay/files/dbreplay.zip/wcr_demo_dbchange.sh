#!/bin/csh

sqlplus scott/tiger < wcr_demo_change.sql
