csh -c 'pkill -9 ^wrc$'
