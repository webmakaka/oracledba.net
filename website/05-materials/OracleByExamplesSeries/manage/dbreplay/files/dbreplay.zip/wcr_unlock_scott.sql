alter user scott account unlock;
alter user scott identified by tiger;

